<?php

  session_start();

  require 'connection.php';

  if(isset($_POST['select'])) {

    $_SESSION['regno_tea'] = $_POST['regno'];

    $query = "INSERT INTO final VALUES('".$_SESSION['regno']."','".$_SESSION['sub']."','".$_SESSION['day']."','".$_SESSION['time']."','".$_SESSION['regno_tea']."')";
    echo $query;
    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "<b>
        common errors while choosing preferences :- </b><br><br>
        1.---------------<br><br>
        2.-----------------<br><br>
        3.-----------------.<br><br>
        <a href='student-register.html'>Try signing up again</a>
        ";
    die();
    }
    $_SESSION['success']='added';
    header("location: student-info.php");

  }

  ?>
