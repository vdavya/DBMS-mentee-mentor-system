<?php

session_start();

require 'connection.php';

$query="select a.*, b.*, c.* from final as a inner join student as b on a.regno_s = b.regno_s right join instructor as c on a.regno_t = c.regno_t where c.regno_t ='".$_SESSION['regno']."'";
$result = mysqli_query($conn, $query);
$resultcheck = mysqli_num_rows($result);
if (!$result) {
    echo "<b>
    common errors while selecting :- </b><br><br>
    1.---------------<br><br>
    2.-----------------<br><br>
    3.-----------------.<br><br>
    <a href='student-preferences.html'>Try signing up again</a>
    ";
die();
}
else{
  if($resultcheck > 0){
    $row = mysqli_fetch_assoc($result);
  }
  else{
    echo "0 results";
  }
}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>My Information</title>

    <link rel="stylesheet" href="styles.css?<?php echo time(); ?>"/>
  </head>
  <body id="info-body">

    <div class="entireinfo-body">

      <div class="nav-bar">
        <div class="left-side">
          <div class="logo-image-locator">
            <img src="images/logo.png"
                height="100px" width="100px" />
          </div>
        </div>

        <div class="right-side">
          <div class="nav-link">
            <a href="index.html">HOME</a>
          </div>
          <div class="nav-link">
            <a href="about.html">ABOUT</a>
          </div>
          <div class="nav-link">
            <a href="logout.php">LOGOUT</a>
          </div>
        </div>
      </div>


      <div class="my-instructors-wrapper">
        <h2>My Students</h2>

        <div class="my-instructor">
          <div class="instructor-section sub">
            <h3> <?php echo $row['subject']; ?> </h3>
          </div>

          <div class="instructor-section days">
            <h3> <?php echo $row['days']; ?> </h3>
          </div>

          <div class="instructor-section timings">
            <h3> <?php echo $row['time']; ?> </h3>
          </div>
        </div>

        <div class="my-instructor-details">
          <div class="instructor-dp">
            <img src="images/instructor-dp2.png" class="instructor-dp" height="120px" width="120px">
          </div>
          <div class="myinstructor-details">
            <h3> <?php echo $row['first_s'].' '.$row['last_s'].' '.'-'.' '.$row['regno_s']; ?> </h3>
            <h3> <?php echo $row['phno_s']; ?> </h3>
            <h3> <?php echo $row['email_s']; ?> </h3>
          </div>
        </div>

      </div>

      <div class="my-info-wrapper">
        <h2>My Information</h2>

        <div class="student-avatar">
          <img src="images/instructor-dp2.png" class="student-avatar" height="200px" width="200px">
        </div>

        <div class="student-profile">
          <h3>Type: Instructor</h3>
          <p> <?php echo $row['first_t'].' '.$row['last_t']; ?> </p>
          <p><?php echo $row['regno_t']; ?> </p>
          <p> <?php echo $row['phno_t']; ?> </p>
          <p> <?php echo $row['email_t']; ?> </p>
        </div>

      </div>
    </div>

  </body>
<html>
