<?php

session_start();

require 'connection.php';

if(isset($_POST['submit'])) {

  $_SESSION['sub'] = $_POST['subject'];
  $_SESSION['day'] = $_POST['days'];
  $_SESSION['time'] = $_POST['time'];
  //$regno = $_POST['regno'];

  $query = "INSERT INTO instructor_pref VALUES('".$_SESSION['regno']."','".$_SESSION['sub']."','".$_SESSION['day']."','".$_SESSION['time']."')";
  echo $query;
  $result = mysqli_query($conn, $query);
  if (!$result) {
      echo "<b>
      common errors while choosing preferences :- </b><br><br>
      1.---------------<br><br>
      2.-----------------<br><br>
      3.-----------------.<br><br>
      <a href='instructor-prefereces.html'>Try signing up again</a>
      ";
  die();
  }
  $_SESSION['success']='added';
  header("location: instructor-info.php");

}

?>
