<?php

session_start();

require 'connection.php';

if(isset($_POST['submit'])){


  $_SESSION['regno'] = $_POST['regno'];
  $pwd = $_POST['password'];
  $identity = $_POST['identity'];

if(empty($_SESSION['regno']) || empty($pwd)){
  header("Location: login.html");
  exit();
}
else{

  if($identity =='student'){
  $sql = "SELECT * FROM student WHERE regno_s = '".$_SESSION['regno']."'";
}
  else{
  $sql = "SELECT * FROM instructor WHERE regno_t = '".$_SESSION['regno']."'";
  }
  echo $sql;
  $result = mysqli_query($conn, $sql);

  if ($result) {
  	$rowcount=mysqli_num_rows($result);

  	if($rowcount==1)
  	{
  		$_SESSION['success']='added';
      if($identity =='student'){
  header("location: student-info.php");
}
else{
  header("location: instructor-info.php");
  	}
  }
  	else{

  		header("Location:login.php");
  	}
  }
  else
  {

  		header("Location:login.php");
  }

}

}
else {
   header("Location: login.html");
  exit();
}

?>
