-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 27, 2020 at 12:51 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meetspace`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `subject` varchar(50) NOT NULL,
  `days` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`subject`, `days`, `time`) VALUES
('CSE1007 - JAVA', 'Monday - Wednesday - Friday', '10:00 - 12:00'),
('CSE1007 - JAVA', 'Monday - Wednesday - Friday', '14:00 - 16:00'),
('CSE1007 - JAVA', 'Monday - Wednesday - Friday', '16:00 - 18:00'),
('CSE1007 - JAVA', 'Monday - Wednesday - Friday', '18:00 - 20:00'),
('CSE1007 - JAVA', 'Monday - Wednesday - Friday', '8:00 - 10:00'),
('CSE1007 - JAVA', 'Tuesday - Thursday - Saturday', '10:00 - 12:00'),
('CSE1007 - JAVA', 'Tuesday - Thursday - Saturday', '14:00 - 16:00'),
('CSE1007 - JAVA', 'Tuesday - Thursday - Saturday', '16:00 - 18:00'),
('CSE1007 - JAVA', 'Tuesday - Thursday - Saturday', '18:00 - 20:00'),
('CSE1007 - JAVA', 'Tuesday - Thursday - Saturday', '8:00 - 10:00'),
('CSE1007 - JAVA', 'Wednesday - Saturday - Sunday', '10:00 - 12:00'),
('CSE1007 - JAVA', 'Wednesday - Saturday - Sunday', '14:00 - 16:00'),
('CSE1007 - JAVA', 'Wednesday - Saturday - Sunday', '16:00 - 18:00'),
('CSE1007 - JAVA', 'Wednesday - Saturday - Sunday', '18:00 - 20:00'),
('CSE1007 - JAVA', 'Wednesday - Saturday - Sunday', '8:00 - 10:00'),
('CSE2001 - CAO', 'Monday - Wednesday - Friday', '10:00 - 12:00'),
('CSE2001 - CAO', 'Monday - Wednesday - Friday', '14:00 - 16:00'),
('CSE2001 - CAO', 'Monday - Wednesday - Friday', '16:00 - 18:00'),
('CSE2001 - CAO', 'Monday - Wednesday - Friday', '18:00 - 20:00'),
('CSE2001 - CAO', 'Monday - Wednesday - Friday', '8:00 - 10:00'),
('CSE2001 - CAO', 'Tuesday - Thursday - Saturday', '10:00 - 12:00'),
('CSE2001 - CAO', 'Tuesday - Thursday - Saturday', '14:00 - 16:00'),
('CSE2001 - CAO', 'Tuesday - Thursday - Saturday', '16:00 - 18:00'),
('CSE2001 - CAO', 'Tuesday - Thursday - Saturday', '18:00 - 20:00'),
('CSE2001 - CAO', 'Tuesday - Thursday - Saturday', '8:00 - 10:00'),
('CSE2001 - CAO', 'Wednesday - Saturday - Sunday', '10:00 - 12:00'),
('CSE2001 - CAO', 'Wednesday - Saturday - Sunday', '14:00 - 16:00'),
('CSE2001 - CAO', 'Wednesday - Saturday - Sunday', '16:00 - 18:00'),
('CSE2001 - CAO', 'Wednesday - Saturday - Sunday', '18:00 - 20:00'),
('CSE2001 - CAO', 'Wednesday - Saturday - Sunday', '8:00 - 10:00'),
('CSE2003 - DSA', 'Monday - Wednesday - Friday', '10:00 - 12:00'),
('CSE2003 - DSA', 'Monday - Wednesday - Friday', '14:00 - 16:00'),
('CSE2003 - DSA', 'Monday - Wednesday - Friday', '16:00 - 18:00'),
('CSE2003 - DSA', 'Monday - Wednesday - Friday', '18:00 - 20:00'),
('CSE2003 - DSA', 'Monday - Wednesday - Friday', '8:00 - 10:00'),
('CSE2003 - DSA', 'Tuesday - Thursday - Saturday', '10:00 - 12:00'),
('CSE2003 - DSA', 'Tuesday - Thursday - Saturday', '14:00 - 16:00'),
('CSE2003 - DSA', 'Tuesday - Thursday - Saturday', '16:00 - 18:00'),
('CSE2003 - DSA', 'Tuesday - Thursday - Saturday', '18:00 - 20:00'),
('CSE2003 - DSA', 'Tuesday - Thursday - Saturday', '8:00 - 10:00'),
('CSE2003 - DSA', 'Wednesday - Saturday - Sunday', '10:00 - 12:00'),
('CSE2003 - DSA', 'Wednesday - Saturday - Sunday', '14:00 - 16:00'),
('CSE2003 - DSA', 'Wednesday - Saturday - Sunday', '16:00 - 18:00'),
('CSE2003 - DSA', 'Wednesday - Saturday - Sunday', '18:00 - 20:00'),
('CSE2003 - DSA', 'Wednesday - Saturday - Sunday', '8:00 - 10:00'),
('CSE2004 - DBMS', 'Monday - Wednesday - Friday', '10:00 - 12:00'),
('CSE2004 - DBMS', 'Monday - Wednesday - Friday', '14:00 - 16:00'),
('CSE2004 - DBMS', 'Monday - Wednesday - Friday', '16:00 - 18:00'),
('CSE2004 - DBMS', 'Monday - Wednesday - Friday', '18:00 - 20:00'),
('CSE2004 - DBMS', 'Monday - Wednesday - Friday', '8:00 - 10:00'),
('CSE2004 - DBMS', 'Tuesday - Thursday - Saturday', '10:00 - 12:00'),
('CSE2004 - DBMS', 'Tuesday - Thursday - Saturday', '14:00 - 16:00'),
('CSE2004 - DBMS', 'Tuesday - Thursday - Saturday', '16:00 - 18:00'),
('CSE2004 - DBMS', 'Tuesday - Thursday - Saturday', '18:00 - 20:00'),
('CSE2004 - DBMS', 'Tuesday - Thursday - Saturday', '8:00 - 10:00'),
('CSE2004 - DBMS', 'Wednesday - Saturday - Sunday', '10:00 - 12:00'),
('CSE2004 - DBMS', 'Wednesday - Saturday - Sunday', '14:00 - 16:00'),
('CSE2004 - DBMS', 'Wednesday - Saturday - Sunday', '16:00 - 18:00'),
('CSE2004 - DBMS', 'Wednesday - Saturday - Sunday', '18:00 - 20:00'),
('CSE2004 - DBMS', 'Wednesday - Saturday - Sunday', '8:00 - 10:00'),
('CSE2005 - OS', 'Monday - Wednesday - Friday', '10:00 - 12:00'),
('CSE2005 - OS', 'Monday - Wednesday - Friday', '14:00 - 16:00'),
('CSE2005 - OS', 'Monday - Wednesday - Friday', '16:00 - 18:00'),
('CSE2005 - OS', 'Monday - Wednesday - Friday', '18:00 - 20:00'),
('CSE2005 - OS', 'Monday - Wednesday - Friday', '8:00 - 10:00'),
('CSE2005 - OS', 'Tuesday - Thursday - Saturday', '10:00 - 12:00'),
('CSE2005 - OS', 'Tuesday - Thursday - Saturday', '14:00 - 16:00'),
('CSE2005 - OS', 'Tuesday - Thursday - Saturday', '16:00 - 18:00'),
('CSE2005 - OS', 'Tuesday - Thursday - Saturday', '18:00 - 20:00'),
('CSE2005 - OS', 'Tuesday - Thursday - Saturday', '8:00 - 10:00'),
('CSE2005 - OS', 'Wednesday - Saturday - Sunday', '10:00 - 12:00'),
('CSE2005 - OS', 'Wednesday - Saturday - Sunday', '14:00 - 16:00'),
('CSE2005 - OS', 'Wednesday - Saturday - Sunday', '16:00 - 18:00'),
('CSE2005 - OS', 'Wednesday - Saturday - Sunday', '18:00 - 20:00'),
('CSE2005 - OS', 'Wednesday - Saturday - Sunday', '8:00 - 10:00'),
('MAT2002 - AOD', 'Monday - Wednesday - Friday', '10:00 - 12:00'),
('MAT2002 - AOD', 'Monday - Wednesday - Friday', '14:00 - 16:00'),
('MAT2002 - AOD', 'Monday - Wednesday - Friday', '16:00 - 18:00'),
('MAT2002 - AOD', 'Monday - Wednesday - Friday', '18:00 - 20:00'),
('MAT2002 - AOD', 'Monday - Wednesday - Friday', '8:00 - 10:00'),
('MAT2002 - AOD', 'Tuesday - Thursday - Saturday', '10:00 - 12:00'),
('MAT2002 - AOD', 'Tuesday - Thursday - Saturday', '14:00 - 16:00'),
('MAT2002 - AOD', 'Tuesday - Thursday - Saturday', '16:00 - 18:00'),
('MAT2002 - AOD', 'Tuesday - Thursday - Saturday', '18:00 - 20:00'),
('MAT2002 - AOD', 'Tuesday - Thursday - Saturday', '8:00 - 10:00'),
('MAT2002 - AOD', 'Wednesday - Saturday - Sunday', '10:00 - 12:00'),
('MAT2002 - AOD', 'Wednesday - Saturday - Sunday', '14:00 - 16:00'),
('MAT2002 - AOD', 'Wednesday - Saturday - Sunday', '16:00 - 18:00'),
('MAT2002 - AOD', 'Wednesday - Saturday - Sunday', '18:00 - 20:00'),
('MAT2002 - AOD', 'Wednesday - Saturday - Sunday', '8:00 - 10:00');

-- --------------------------------------------------------

--
-- Table structure for table `final`
--

CREATE TABLE `final` (
  `regno_s` varchar(10) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `days` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL,
  `regno_t` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `final`
--

-- --------------------------------------------------------

--
-- Table structure for table `instructor`
--

CREATE TABLE `instructor` (
  `regno_t` varchar(10) NOT NULL,
  `first_t` varchar(50) NOT NULL,
  `last_t` varchar(50) NOT NULL,
  `phno_t` varchar(50) NOT NULL,
  `email_t` varchar(50) NOT NULL,
  `password_t` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor`
--

-- --------------------------------------------------------

--
-- Table structure for table `instructor_pref`
--

CREATE TABLE `instructor_pref` (
  `regno_t` varchar(10) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `days` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `instructor_pref`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `regno_s` varchar(10) NOT NULL,
  `first_s` varchar(50) NOT NULL,
  `last_s` varchar(50) NOT NULL,
  `phno_s` varchar(50) NOT NULL,
  `email_s` varchar(50) NOT NULL,
  `password_s` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_pref`
--

CREATE TABLE `student_pref` (
  `regno_s` varchar(10) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `days` varchar(50) NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_pref`
--

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`subject`,`days`,`time`);

--
-- Indexes for table `final`
--
ALTER TABLE `final`
  ADD KEY `regno_s` (`regno_s`),
  ADD KEY `regno_t` (`regno_t`),
  ADD KEY `subject` (`subject`,`days`,`time`);

--
-- Indexes for table `instructor`
--
ALTER TABLE `instructor`
  ADD PRIMARY KEY (`regno_t`);

--
-- Indexes for table `instructor_pref`
--
ALTER TABLE `instructor_pref`
  ADD KEY `regno_t` (`regno_t`),
  ADD KEY `subject` (`subject`,`days`,`time`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`regno_s`);

--
-- Indexes for table `student_pref`
--
ALTER TABLE `student_pref`
  ADD KEY `regno_s` (`regno_s`),
  ADD KEY `subject` (`subject`,`days`,`time`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `final`
--
ALTER TABLE `final`
  ADD CONSTRAINT `final_ibfk_1` FOREIGN KEY (`regno_s`) REFERENCES `student` (`regno_s`),
  ADD CONSTRAINT `final_ibfk_2` FOREIGN KEY (`regno_t`) REFERENCES `instructor` (`regno_t`),
  ADD CONSTRAINT `final_ibfk_3` FOREIGN KEY (`subject`,`days`,`time`) REFERENCES `course` (`subject`, `days`, `time`);

--
-- Constraints for table `instructor_pref`
--
ALTER TABLE `instructor_pref`
  ADD CONSTRAINT `instructor_pref_ibfk_1` FOREIGN KEY (`regno_t`) REFERENCES `instructor` (`regno_t`),
  ADD CONSTRAINT `instructor_pref_ibfk_2` FOREIGN KEY (`subject`,`days`,`time`) REFERENCES `course` (`subject`, `days`, `time`);

--
-- Constraints for table `student_pref`
--
ALTER TABLE `student_pref`
  ADD CONSTRAINT `student_pref_ibfk_1` FOREIGN KEY (`regno_s`) REFERENCES `student` (`regno_s`),
  ADD CONSTRAINT `student_pref_ibfk_2` FOREIGN KEY (`subject`,`days`,`time`) REFERENCES `course` (`subject`, `days`, `time`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
