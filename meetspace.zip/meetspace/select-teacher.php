
<?php

session_start();

require 'connection.php';

$query="select a.*, b.*, c.*, d.* from student_pref as a inner join instructor_pref as b on a.subject = b.subject and a.days = b.days and a.time = b.time INNER join student as c on a.regno_s = c.regno_s INNER join instructor as d on b.regno_t = d.regno_t where a.regno_s='".$_SESSION['regno']."'";
$result = mysqli_query($conn, $query);
$resultcheck = mysqli_num_rows($result);
if (!$result) {
    echo "<b>
    common errors while selecting :- </b><br><br>
    1.---------------<br><br>
    2.-----------------<br><br>
    3.-----------------.<br><br>
    <a href='student-preferences.html'>Try signing up again</a>
    ";
die();
}
else{
  if($resultcheck > 0){
    //$row = mysqli_fetch_assoc($result);
  }

}

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset = "utf-8" />
    <title>DBMS</title>
    <link rel="stylesheet" href="styles.css?<?php echo time(); ?>"/>

  </head>
  <body id="choose-body">

    <div class="entireselect-body">

      <div class="nav-bar">
        <div class="left-side">
          <div class="logo-image-locator">
            <img src="images/logo.png"
                height="100px" width="100px" />
          </div>
        </div>

        <div class="right-side">
          <div class="nav-link">
            <a href="index.html">HOME</a>
          </div>
          <div class="nav-link">
            <a href="about.html">ABOUT</a>
          </div>
          <div class="nav-link">
            <a href="logout.php">LOGOUT</a>
          </div>
        </div>
      </div>



        <div class="preferences-wrapper">

          <h2 class="your-pref-header">Your Preferences</h2>

          <div class="your-preferences">
            <div class="pref-section sub">
              <h3 class="prefsection"> <?php echo $_SESSION['sub']; ?> </h3>
            </div>

            <div class="pref-section days">
              <h3 class="prefsection"> <?php echo $_SESSION['day']; ?> </h3>
            </div>

            <div class="pref-section timings">
              <h3 class="prefsection"> <?php echo $_SESSION['time']; ?> </h3>
            </div>
          </div>

        </div>

        <div class="available-wrapper">

          <h2 class="available-header">Available Instructors</h3>

            <?php while($row = mysqli_fetch_assoc($result)){?>

          <div class="avail-instructors">

            <div class="instructor-dp">
              <img src="images/instructor-dp2.png" class="instructor-dp" height="120px" width="120px">
            </div>
            <div class="instructor-details">

              <h3 id="teachername"> Name:  <?php echo $row['first_t'].' '.$row['last_t']; ?> </h3>
              <h3 id="phonenumber"> Phone Number:  <?php echo $row['phno_t']; ?> </h3>
              <h3 id="email"> Email: <?php echo $row['email_t']; ?></h3>
            </div>
            <form action="info-store.php" method="POST">
              <input hidden class="regno" type="text" name="regno" value=<?php echo $row['regno_t']?>>


            <input class="pref-button" type="submit" name="select" value"select">
          </form>

          </div>
          <?}?>
        </div>

      </div>

  </body>
</html>
