 -- join for select - teacher
select a.*, b.*, c.*, d.* from student_pref as a inner join instructor_pref as b on a.subject = b.subject and a.days = b.days and a.time = b.time INNER join student as c on a.regno_s = c.regno_s INNER join instructor as d on b.regno_t = d.regno_t where a.regno_s='$reg'


select a.*, b.*, c.* from final as a inner join student as b on a.regno_s = b.regno_s inner join instructor as c on a.regno_t = c.regno_t where a.regno_s =

select a.*, b.*, c.* from final as a inner join student as b on a.regno_s = b.regno_s right join instructor as c on a.regno_t = c.regno_t where c.regno_t =
