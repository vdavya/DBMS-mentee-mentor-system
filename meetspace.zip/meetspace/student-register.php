<?php

session_start();

require 'connection.php';


if(isset($_POST['submit'])) {


  $_SESSION['regno']= $_POST['regno'];
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $phonenumber = $_POST['phonenumber'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $confirmpassword = $_POST['confirmpassword'];


  if(!preg_match("/^[0-9]{2}[a-zA-Z]{3}[0-9]{4}$/",$_SESSION['regno'])) {
  echo nl2br("Invalid Registration Number");
  }

  if(!preg_match("/^([a-zA-Z' ]+)$/",$firstname)) {
  echo nl2br("\n\nInvalid First Name");
  }

  if(!preg_match("/^([a-zA-Z' ]+)$/",$lastname)) {
  echo nl2br("\n\nInvalid Last Name");
  }

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
  echo nl2br("\n\nInvalid Email");
}

  if(!preg_match("/^[0-9]{10}$/", $phonenumber)) {
  echo nl2br("\n\nInvalid Phone Number<br><br>");
}

if ($password !== $confirmpassword) {
   echo nl2br("Password and Confirm Password do not match.");
}

  $query = "INSERT INTO student VALUES('".$_SESSION['regno']."','$firstname','$lastname','$phonenumber','$email','$password')";
  echo $query;
  $result = mysqli_query($conn, $query);
  if (!$result) {
      echo "<b><br><br><br>Error occured while signing up</b>

      <br><br><a href='student-register.html'>Sign up again</a>
      ";
  die();
  }
  $_SESSION['success']='added';
  //$regno = $_SESSION['regno'];
  header("location: student-preferences.html");

}

?>
